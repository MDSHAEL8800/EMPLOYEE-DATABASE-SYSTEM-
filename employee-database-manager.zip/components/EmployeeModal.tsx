import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { Employee } from '../types';
import { UploadIcon, PhoneIcon } from './Icons';

const departments = ["Engineering", "Design", "Human Resources", "Sales", "Management"];

interface InputFieldProps {
    id: string;
    label: string;
    type?: string;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    required?: boolean;
    placeholder?: string;
    icon?: React.ReactNode;
}

const InputField: React.FC<InputFieldProps> = ({ id, label, type = 'text', value, onChange, required = true, placeholder = '', icon }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-gray-300">{label}</label>
        <div className="mt-1 relative">
            {icon && (
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    {icon}
                </div>
            )}
            <input
                type={type}
                id={id}
                name={id}
                value={value}
                onChange={onChange}
                required={required}
                placeholder={placeholder}
                className={`appearance-none block w-full ${icon ? 'pl-10' : 'px-3'} py-2 border border-slate-600 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-slate-700/50`}
            />
        </div>
    </div>
);

interface EmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (employee: Employee) => void;
  employee: Employee | null;
}

const EmployeeModal: React.FC<EmployeeModalProps> = ({ isOpen, onClose, onSave, employee }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    contact: '',
    address: '',
    position: '',
    department: departments[0],
    performance: '50',
    income: '',
    avatarUrl: ''
  });
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (employee) {
      setFormData({
        name: employee.name,
        email: employee.email,
        contact: employee.contact,
        address: employee.address,
        position: employee.position,
        department: employee.department,
        performance: String(employee.performance),
        income: String(employee.income),
        avatarUrl: employee.avatarUrl,
      });
    } else {
      setFormData({
        name: '', email: '', contact: '', address: '', position: '',
        department: departments[0], performance: '50', income: '', avatarUrl: ''
      });
    }
  }, [employee, isOpen]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, avatarUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileSelect = () => fileInputRef.current?.click();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const employeeData: Employee = {
      id: employee?.id || new Date().getTime().toString(),
      name: formData.name,
      email: formData.email,
      contact: formData.contact,
      address: formData.address,
      position: formData.position,
      department: formData.department,
      performance: Number(formData.performance),
      income: Number(formData.income),
      avatarUrl: formData.avatarUrl || `https://picsum.photos/seed/${formData.name || 'new'}/200`
    };
    onSave(employeeData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex justify-center items-center animate-fade-in p-4" onClick={onClose}>
      <div className="bg-slate-800/80 backdrop-blur-2xl rounded-2xl shadow-xl w-full max-w-lg p-6 sm:p-8 transform transition-all animate-modal-slide-up ring-1 ring-black ring-opacity-20" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-2xl font-bold text-white mb-6">
          {employee ? 'Edit Employee' : 'Add New Employee'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                  <img
                      className="h-24 w-24 rounded-full object-cover shadow-lg ring-4 ring-slate-700/50"
                      src={formData.avatarUrl || `https://ui-avatars.com/api/?name=${formData.name.split(' ').join('+') || 'New'}&background=0ea5e9&color=fff&size=96&font-size=0.33`}
                      alt="Profile"
                  />
                  <button
                      type="button"
                      onClick={triggerFileSelect}
                      className="absolute bottom-0 -right-2 bg-slate-700 p-1.5 rounded-full shadow-md hover:bg-slate-600 transition ring-2 ring-slate-800"
                      aria-label="Change profile picture"
                  >
                      <UploadIcon className="h-5 w-5 text-primary" />
                  </button>
                  <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleImageChange}
                      className="hidden"
                      accept="image/png, image/jpeg"
                  />
              </div>
          </div>

          <InputField id="name" label="Full Name" value={formData.name} onChange={handleChange} placeholder="John Doe" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <InputField id="email" label="Email Address" type="email" value={formData.email} onChange={handleChange} placeholder="john.doe@example.com"/>
             <InputField 
                id="contact" 
                label="Contact Number" 
                type="tel" 
                value={formData.contact} 
                onChange={handleChange} 
                placeholder="123-456-7890"
                icon={<PhoneIcon className="h-5 w-5 text-gray-400" />}
             />
          </div>
          <InputField id="address" label="Address" value={formData.address} onChange={handleChange} placeholder="123 Main St, Anytown" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InputField id="position" label="Position" value={formData.position} onChange={handleChange} placeholder="Software Engineer" />
            <div>
                 <label htmlFor="department" className="block text-sm font-medium text-gray-300">Department</label>
                 <select
                    id="department"
                    name="department"
                    value={formData.department}
                    onChange={handleChange}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-600 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md bg-slate-700/50"
                 >
                    {departments.map(dep => <option key={dep}>{dep}</option>)}
                 </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <InputField id="income" label="Annual Income (USD)" type="number" value={formData.income} onChange={handleChange} placeholder="90000" />
            <div>
                 <label htmlFor="performance" className="block text-sm font-medium text-gray-300">Performance ({formData.performance}%)</label>
                 <input
                    id="performance"
                    name="performance"
                    type="range"
                    min="0"
                    max="100"
                    value={formData.performance}
                    onChange={handleChange}
                    className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer mt-2 accent-primary"
                />
            </div>
          </div>
          <div className="pt-4 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-200 bg-slate-700/80 border border-slate-500 rounded-lg shadow-sm hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-transform active:scale-95"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-br from-primary to-sky-400 rounded-lg shadow-md hover:from-primary-hover hover:to-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary focus:ring-offset-slate-800 transition-all transform hover:scale-105 active:scale-100"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EmployeeModal;