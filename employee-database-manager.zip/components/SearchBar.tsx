
import React, { useState } from 'react';
import { SearchIcon, XIcon } from './Icons';

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ searchTerm, onSearchChange }) => {
  const [colorIndex, setColorIndex] = useState(0);

  const bgColors = [
    'bg-slate-800',
    'bg-sky-900/40',
    'bg-indigo-900/40',
    'bg-purple-900/40',
    'bg-teal-900/40',
  ];

  const handleContainerClick = () => {
    setColorIndex((prevIndex) => (prevIndex + 1) % bgColors.length);
  };
  
  const handleClear = () => {
    onSearchChange('');
  };

  return (
    <div className="relative w-full max-w-md group cursor-pointer" onClick={handleContainerClick}>
      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none z-10">
        <SearchIcon className="h-5 w-5 text-gray-400 transition-all duration-300 group-focus-within:text-primary group-focus-within:scale-110" />
      </div>
      <input
        type="text"
        placeholder="Find colleagues by name, email, or position..."
        value={searchTerm}
        onChange={(e) => onSearchChange(e.target.value)}
        onClick={(e) => e.stopPropagation()}
        className={`block w-full pl-12 pr-12 py-3 border-transparent rounded-full leading-5 text-gray-100 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-primary sm:text-sm transition-all duration-300 shadow-lg focus:shadow-primary-glow ring-1 ring-slate-700/50 focus:ring-offset-2 focus:ring-offset-slate-900 cursor-text ${bgColors[colorIndex]}`}
      />
      {searchTerm && (
        <div className="absolute inset-y-0 right-0 pr-4 flex items-center z-10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleClear();
            }}
            className="p-1 rounded-full text-gray-500 hover:text-white hover:bg-slate-700/50 focus:outline-none focus:ring-2 focus:ring-slate-600 transition-all"
            aria-label="Clear search"
          >
            <XIcon className="h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default SearchBar;