import React from 'react';
import { PlusIcon, UsersIcon } from './Icons';

interface HeaderProps {
  onAddEmployee: () => void;
}

const Header: React.FC<HeaderProps> = ({ onAddEmployee }) => {
  return (
    <header className="bg-slate-900/70 backdrop-blur-lg shadow-lg sticky top-0 z-40 animate-app-slide-down opacity-0">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
             <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-primary/20">
                <UsersIcon className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-white ml-3 tracking-wider">EmployeeDB</h1>
          </div>
          <div className="flex items-center">
            <button
              onClick={onAddEmployee}
              className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-br from-primary to-sky-400 hover:from-primary-hover hover:to-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary focus:ring-offset-slate-900 transition-all transform hover:scale-105 active:scale-100 shadow-lg"
              aria-label="Add new employee"
            >
              <PlusIcon className="h-5 w-5 mr-2 -ml-1" />
              <span>Add Employee</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;