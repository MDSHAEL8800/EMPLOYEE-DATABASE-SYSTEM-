import React from 'react';
import type { Employee } from '../types';
import { EditIcon, TrashIcon, UsersIcon, PhoneIcon } from './Icons';

interface EmployeeTableProps {
  employees: Employee[];
  onEdit: (employee: Employee) => void;
  onDelete: (id: string) => void;
}

const PerformanceIndicator: React.FC<{ score: number }> = ({ score }) => {
    const [displayedScore, setDisplayedScore] = React.useState(0);

    React.useEffect(() => {
        const timeout = setTimeout(() => setDisplayedScore(score), 100);
        return () => clearTimeout(timeout);
    }, [score]);

    const getPerformanceColor = (s: number) => {
        if (s >= 80) return 'from-green-400 to-emerald-500';
        if (s >= 50) return 'from-yellow-400 to-amber-500';
        return 'from-orange-500 to-red-600';
    };

    return (
        <div className="flex items-center">
            <div className="w-24 bg-slate-700 rounded-full h-2 mr-2 overflow-hidden">
                <div
                    className={`bg-gradient-to-r ${getPerformanceColor(displayedScore)} h-2 rounded-full transition-all duration-1000 ease-out`}
                    style={{ width: `${displayedScore}%` }}
                ></div>
            </div>
            <span className="text-sm font-medium text-gray-300">{score}%</span>
        </div>
    );
};


const EmployeeTableRow: React.FC<{ employee: Employee; onEdit: (employee: Employee) => void; onDelete: (id: string) => void }> = ({ employee, onEdit, onDelete }) => {
  return (
    <tr className="hover:bg-gray-500/10 transition-colors duration-200">
      <td className="px-6 py-5 whitespace-nowrap">
        <div className="flex items-center">
          <div className="flex-shrink-0 h-12 w-12">
            <img className="h-12 w-12 rounded-full object-cover ring-2 ring-slate-700/50" src={employee.avatarUrl} alt={employee.name} />
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-white">{employee.name}</div>
            <div className="text-sm text-gray-400">{employee.email}</div>
            <div className="flex items-center mt-1 text-sm text-sky-400">
              <PhoneIcon className="h-4 w-4 mr-1.5 text-sky-500/80" />
              {employee.contact}
            </div>
          </div>
        </div>
      </td>
      <td className="px-6 py-5 whitespace-nowrap">
        <div className="text-sm text-gray-200">{employee.position}</div>
      </td>
      <td className="px-6 py-5 whitespace-nowrap text-sm text-gray-400">
        {employee.department}
      </td>
       <td className="px-6 py-5 whitespace-nowrap text-sm text-gray-400 max-w-xs truncate">
        {employee.address}
      </td>
      <td className="px-6 py-5 whitespace-nowrap text-sm font-semibold text-cyan-400">
        {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(employee.income)}
      </td>
       <td className="px-6 py-5 whitespace-nowrap">
        <PerformanceIndicator score={employee.performance} />
      </td>
      <td className="px-6 py-5 whitespace-nowrap text-right text-sm font-medium">
        <div className="flex items-center justify-end space-x-4">
          <button onClick={() => onEdit(employee)} className="text-gray-400 hover:text-primary transition-all duration-200 transform hover:scale-125" aria-label={`Edit ${employee.name}`}>
            <EditIcon className="h-5 w-5" />
          </button>
          <button onClick={() => onDelete(employee.id)} className="text-gray-400 hover:text-danger transition-all duration-200 transform hover:scale-125" aria-label={`Delete ${employee.name}`}>
            <TrashIcon className="h-5 w-5" />
          </button>
        </div>
      </td>
    </tr>
  );
};

const EmployeeTable: React.FC<EmployeeTableProps> = ({ employees, onEdit, onDelete }) => {
  return (
    <div className="align-middle inline-block min-w-full">
        <div className="overflow-hidden">
            <table className="min-w-full">
                <thead className="bg-transparent">
                    <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Employee
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Position
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Department
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Address
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Income
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Performance
                        </th>
                        <th scope="col" className="relative px-6 py-3">
                            <span className="sr-only">Actions</span>
                        </th>
                    </tr>
                </thead>
                <tbody className="bg-transparent">
                    {employees.length > 0 ? (
                        employees.map((employee) => (
                            <EmployeeTableRow key={employee.id} employee={employee} onEdit={onEdit} onDelete={onDelete} />
                        ))
                    ) : (
                        <tr>
                            <td colSpan={7} className="px-6 py-16 text-center">
                                <div className="flex flex-col items-center">
                                    <UsersIcon className="h-12 w-12 text-gray-400" />
                                    <p className="mt-4 text-gray-400">No employees found.</p>
                                    <p className="text-sm text-gray-500">Try adjusting your search or adding a new employee.</p>
                                </div>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default EmployeeTable;