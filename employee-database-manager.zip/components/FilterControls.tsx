import React from 'react';
import { ArrowUpIcon, ArrowDownIcon } from './Icons';

interface FilterControlsProps {
  sortKey: string;
  onSortKeyChange: (key: string) => void;
  sortOrder: 'asc' | 'desc';
  onSortOrderChange: () => void;
  positions: string[];
  positionFilter: string;
  onPositionFilterChange: (position: string) => void;
}

const SelectInput: React.FC<{
  id: string;
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  children: React.ReactNode;
  className?: string;
}> = ({ id, label, value, onChange, children, className = '' }) => (
  <div className={className}>
    <label htmlFor={id} className="sr-only">{label}</label>
    <select
      id={id}
      value={value}
      onChange={onChange}
      className="block w-full pl-3 pr-10 py-2 border border-slate-600 rounded-lg leading-5 bg-slate-700/50 text-gray-100 placeholder-gray-400 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary focus:border-primary sm:text-sm transition-all duration-200"
    >
      {children}
    </select>
  </div>
);

const FilterControls: React.FC<FilterControlsProps> = ({
  sortKey, onSortKeyChange,
  sortOrder, onSortOrderChange,
  positions, positionFilter, onPositionFilterChange
}) => {
  return (
    <div className="flex flex-col sm:flex-row items-center gap-4">
      <SelectInput
        id="position-filter"
        label="Filter by position"
        value={positionFilter}
        onChange={(e) => onPositionFilterChange(e.target.value)}
        className="w-full sm:w-auto"
      >
        {positions.map(pos => <option key={pos} value={pos}>{pos}</option>)}
      </SelectInput>

      <div className="flex items-center gap-2 w-full sm:w-auto">
        <SelectInput
          id="sort-key"
          label="Sort by"
          value={sortKey}
          onChange={(e) => onSortKeyChange(e.target.value)}
          className="flex-grow"
        >
          <option value="name">Sort by: Name</option>
          <option value="income">Sort by: Salary</option>
          <option value="performance">Sort by: Performance</option>
        </SelectInput>
        
        <button
          onClick={onSortOrderChange}
          className="flex-shrink-0 p-2 border border-slate-600 rounded-lg bg-slate-700/50 hover:bg-slate-700 transition-colors"
          aria-label={`Sort in ${sortOrder === 'asc' ? 'descending' : 'ascending'} order`}
        >
          {sortOrder === 'asc' ? <ArrowUpIcon className="h-5 w-5 text-gray-300" /> : <ArrowDownIcon className="h-5 w-5 text-gray-300" />}
        </button>
      </div>
    </div>
  );
};

export default FilterControls;
