import { useState, useCallback } from 'react';
import type { Employee } from '../types';

const initialEmployees: Employee[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    email: 'alice.j@example.com',
    contact: '123-456-7890',
    address: '123 Maple St, Springfield',
    position: 'Lead Developer',
    department: 'Engineering',
    performance: 92,
    income: 120000,
    avatarUrl: 'https://picsum.photos/seed/alice/200'
  },
  {
    id: '2',
    name: 'Bob Williams',
    email: 'bob.w@example.com',
    contact: '234-567-8901',
    address: '456 Oak Ave, Metropolis',
    position: 'UX Designer',
    department: 'Design',
    performance: 85,
    income: 95000,
    avatarUrl: 'https://picsum.photos/seed/bob/200'
  },
  {
    id: '3',
    name: 'Charlie Brown',
    email: 'charlie.b@example.com',
    contact: '345-678-9012',
    address: '789 Pine Ln, Gotham',
    position: 'Project Manager',
    department: 'Management',
    performance: 78,
    income: 110000,
    avatarUrl: 'https://picsum.photos/seed/charlie/200'
  },
   {
    id: '4',
    name: 'Diana Prince',
    email: 'diana.p@example.com',
    contact: '456-789-0123',
    address: '1 Wonder Way, Themyscira',
    position: 'HR Specialist',
    department: 'Human Resources',
    performance: 98,
    income: 85000,
    avatarUrl: 'https://picsum.photos/seed/diana/200'
  },
  {
    id: '5',
    name: 'Ethan Hunt',
    email: 'ethan.h@example.com',
    contact: '567-890-1234',
    address: '2 Impossible Dr, Langley',
    position: 'Systems Analyst',
    department: 'Engineering',
    performance: 45,
    income: 105000,
    avatarUrl: 'https://picsum.photos/seed/ethan/200'
  }
];

export const useEmployees = () => {
  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);

  const addEmployee = useCallback((employee: Employee) => {
    setEmployees(prev => [employee, ...prev]);
  }, []);

  const updateEmployee = useCallback((updatedEmployee: Employee) => {
    setEmployees(prev =>
      prev.map(emp => (emp.id === updatedEmployee.id ? updatedEmployee : emp))
    );
  }, []);

  const deleteEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.filter(emp => emp.id !== id));
  }, []);

  return { employees, addEmployee, updateEmployee, deleteEmployee };
};